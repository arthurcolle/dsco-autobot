#!/usr/bin/env python3
"""Simple CLI driver for the Anthropic computer-use sampling loop."""

from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Callable

from anthropic import APIResponse
from anthropic.types.beta import (
    BetaContentBlock,
    BetaMessageParam,
    BetaTextBlockParam,
    BetaToolUseBlock,
)
from dotenv import load_dotenv

from loop import APIProvider, PROVIDER_TO_DEFAULT_MODEL_NAME, sampling_loop
from tools import ToolResult

load_dotenv()


def _positive_int(value: str) -> int:
    ivalue = int(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("Value must be non-negative")
    return ivalue


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Interact with the Claude computer-use agent from the terminal.",
    )
    parser.add_argument(
        "--provider",
        default=os.getenv("API_PROVIDER", APIProvider.ANTHROPIC.value),
        choices=[provider.value for provider in APIProvider],
        help="API provider to use (default: %(default)s).",
    )
    parser.add_argument(
        "--model",
        default=os.getenv("ANTHROPIC_MODEL"),
        help="Model identifier to use. Defaults to the provider specific suggestion.",
    )
    parser.add_argument(
        "--api-key",
        default=os.getenv("ANTHROPIC_API_KEY"),
        help="Anthropic API key. Falls back to ANTHROPIC_API_KEY env var.",
    )
    parser.add_argument(
        "--system-suffix",
        default=os.getenv("CLI_SYSTEM_SUFFIX", ""),
        help="Extra instructions appended to the base system prompt.",
    )
    parser.add_argument(
        "--max-tokens",
        type=_positive_int,
        default=4096,
        help="Maximum tokens for each Claude response (default: %(default)s).",
    )
    default_limit = os.getenv("CLI_ONLY_RECENT_IMAGES")
    parser.add_argument(
        "--only-recent-images",
        type=_positive_int,
        default=int(default_limit) if default_limit else 10,
        help="Send only the N most recent screenshots back to the model.",
    )
    parser.add_argument(
        "--prompt",
        help="Optional initial prompt to send without waiting for interactive input.",
    )
    parser.add_argument(
        "--http-log",
        action="store_true",
        help="Print HTTP request/response envelopes for each API call.",
    )
    parser.add_argument(
        "--image-dir",
        default=os.getenv("CLI_IMAGE_DIR", "./computer_use_images"),
        help="Directory to write screenshot outputs. Use '-' to skip saving images.",
    )
    return parser.parse_args()


class CLIRenderer:
    """Handles rendering of agent output to the terminal."""

    def __init__(self, *, http_log: bool, image_dir: str | None):
        self.http_log = http_log
        self._image_counter = 0
        if image_dir and image_dir != "-":
            path = Path(image_dir).expanduser()
            path.mkdir(parents=True, exist_ok=True)
            self.image_dir: Path | None = path
        else:
            self.image_dir = None

    def bot_output(self, block: BetaContentBlock):
        block_type = getattr(block, "type", None)
        if block_type == "text":
            text = getattr(block, "text", "")
            if text:
                print(f"Claude: {text}", flush=True)
        elif block_type == "tool_use":
            block = block  # type: ignore[no-redef]
            tool_block = block if isinstance(block, BetaToolUseBlock) else None
            tool_name = getattr(tool_block, "name", "unknown_tool")
            tool_input = getattr(tool_block, "input", {})
            serialized = json.dumps(tool_input, indent=2, ensure_ascii=False, default=str)
            print(f"Claude requested tool '{tool_name}' with input:\n{serialized}", flush=True)
        else:
            print(f"Claude emitted block: {block}", flush=True)

    def tool_output(self, result: ToolResult, tool_id: str):
        header = f"[tool:{tool_id}]"
        if result.output:
            print(f"{header} output:\n{result.output}", flush=True)
        if result.error:
            print(f"{header} error:\n{result.error}", file=sys.stderr, flush=True)
        if result.base64_image:
            if self.image_dir:
                self._image_counter += 1
                filename = self.image_dir / f"screenshot-{self._image_counter:04d}.png"
                filename.write_bytes(base64.b64decode(result.base64_image))
                print(f"{header} image saved to {filename}", flush=True)
            else:
                print(f"{header} produced an image (not saved; pass --image-dir to store)", flush=True)

    def http_logger(self) -> Callable[[APIResponse], None]:
        if not self.http_log:
            return lambda _response: None

        def _log(response: APIResponse):
            request = response.http_request
            response_headers = response.headers
            print("\n=== HTTP Request ===", flush=True)
            print(f"{request.method} {request.url}", flush=True)
            for key, value in request.headers.items():
                print(f"{key}: {value}", flush=True)
            print(request.read().decode(), flush=True)
            print("=== HTTP Response ===", flush=True)
            print(f"Status: {response.http_response.status_code}", flush=True)
            for key, value in response_headers.items():
                print(f"{key}: {value}", flush=True)
            print(response.http_response.text, flush=True)

        return _log


async def run_chat(args: argparse.Namespace) -> None:
    provider = APIProvider(args.provider)
    model = args.model or PROVIDER_TO_DEFAULT_MODEL_NAME[provider]
    api_key = args.api_key or os.getenv("ANTHROPIC_API_KEY") or ""

    if provider == APIProvider.ANTHROPIC and not api_key:
        raise SystemExit("Anthropic provider selected but no API key was supplied.")

    renderer = CLIRenderer(http_log=args.http_log, image_dir=args.image_dir)

    messages: list[BetaMessageParam] = []
    pending_prompt = args.prompt

    print(
        "Type '/exit' or press Ctrl+C to quit."
        " Send empty lines to repeat the last request.",
        flush=True,
    )

    while True:
        if pending_prompt is not None:
            user_input = pending_prompt.strip()
            pending_prompt = None
        else:
            try:
                user_input = input("You> ").strip()
            except EOFError:
                print()
                break

        if not user_input:
            continue
        if user_input.lower() in {"/exit", "exit", "/quit", "quit"}:
            break

        user_block: BetaTextBlockParam = {"type": "text", "text": user_input}
        messages.append({"role": "user", "content": [user_block]})

        try:
            messages = await sampling_loop(
                system_prompt_suffix=args.system_suffix,
                model=model,
                provider=provider,
                messages=messages,
                output_callback=renderer.bot_output,
                tool_output_callback=renderer.tool_output,
                api_response_callback=renderer.http_logger(),
                api_key=api_key,
                only_n_most_recent_images=args.only_recent_images,
                max_tokens=args.max_tokens,
            )
        except KeyboardInterrupt:
            print("\nInterrupted. Type /exit to quit.", flush=True)
            continue
        except Exception as exc:  # pragma: no cover - defensive logging for CLI use
            print(f"Error during sampling loop: {exc}", file=sys.stderr, flush=True)
            if messages and messages[-1]["role"] == "user":
                messages.pop()


async def main() -> None:
    args = parse_args()
    await run_chat(args)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
