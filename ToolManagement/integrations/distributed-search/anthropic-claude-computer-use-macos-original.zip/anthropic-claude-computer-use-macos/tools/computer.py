import asyncio
import base64
import json
import os
import re
import shlex
import subprocess
from enum import StrEnum
from pathlib import Path
from typing import Any, Literal, TypedDict
from uuid import uuid4

from .base import BaseAnthropicTool, ToolError, ToolResult
from .run import run

OUTPUT_DIR = "/tmp/outputs"

TYPING_DELAY_MS = 12
TYPING_GROUP_SIZE = 50
DEFAULT_WIDTH = 1280
DEFAULT_HEIGHT = 800

Action = Literal[
    "key",
    "type",
    "mouse_move",
    "left_click",
    "left_click_drag",
    "right_click",
    "middle_click",
    "double_click",
    "screenshot",
    "cursor_position",
]


class Resolution(TypedDict):
    width: int
    height: int


# sizes above XGA/WXGA are not recommended (see README.md)
# scale down to one of these targets if ComputerTool._scaling_enabled is set
MAX_SCALING_TARGETS: dict[str, Resolution] = {
    "XGA": Resolution(width=1024, height=768),  # 4:3
    "WXGA": Resolution(width=1280, height=800),  # 16:10
    "FWXGA": Resolution(width=1366, height=768),  # ~16:9
}
SCALE_DESTINATION = MAX_SCALING_TARGETS["FWXGA"]


class ScalingSource(StrEnum):
    COMPUTER = "computer"
    API = "api"


class ComputerToolOptions(TypedDict):
    display_height_px: int
    display_width_px: int
    display_number: int | None


def chunks(s: str, chunk_size: int) -> list[str]:
    return [s[i : i + chunk_size] for i in range(0, len(s), chunk_size)]


class ComputerTool(BaseAnthropicTool):
    """
    A tool that allows the agent to interact with the screen, keyboard, and mouse of the current macOS computer.
    The tool parameters are defined by Anthropic and are not editable.
    Requires cliclick to be installed: brew install cliclick
    """

    name: Literal["computer"] = "computer"
    api_type: str = os.getenv("ANTHROPIC_COMPUTER_USE_TOOL_TYPE", "computer_20251115")
    width: int
    height: int
    display_num: int | None

    _screenshot_delay = 1.0  # macOS is generally faster than X11
    _scaling_enabled = True

    @property
    def options(self) -> ComputerToolOptions:
        return {
            "display_width_px": self.width,
            "display_height_px": self.height,
            "display_number": self.display_num,
        }

    def to_params(self) -> dict[str, Any]:
        return {"name": self.name, "type": self.api_type, **self.options}

    def __init__(self):
        super().__init__()

        self.width, self.height = self._determine_display_size()
        assert self.width and self.height, "Unable to determine screen dimensions"
        self.display_num = None  # macOS doesn't use X11 display numbers

    async def __call__(
        self,
        *,
        action: Action,
        text: str | None = None,
        coordinate: tuple[int, int] | None = None,
        **kwargs,
    ):
        print("Action: ", action, text, coordinate)
        if action in ("mouse_move", "left_click_drag"):
            if coordinate is None:
                raise ToolError(f"coordinate is required for {action}")
            if text is not None:
                raise ToolError(f"text is not accepted for {action}")
            if not isinstance(coordinate, list) or len(coordinate) != 2:
                raise ToolError(f"{coordinate} must be a tuple of length 2")
            if not all(isinstance(i, int) and i >= 0 for i in coordinate):
                raise ToolError(f"{coordinate} must be a tuple of non-negative ints")

            x, y = self.scale_coordinates(ScalingSource.API, coordinate[0], coordinate[1])

            if action == "mouse_move":
                return await self.shell(f"cliclick m:{x},{y}")
            elif action == "left_click_drag":
                return await self.shell(f"cliclick dd:{x},{y}")

        if action in ("key", "type"):
            if text is None:
                raise ToolError(f"text is required for {action}")
            if coordinate is not None:
                raise ToolError(f"coordinate is not accepted for {action}")
            if not isinstance(text, str):
                raise ToolError(output=f"{text} must be a string")

            if action == "key":
                return await self._press_key_sequence(text)
            elif action == "type":
                results: list[ToolResult] = []
                for chunk in chunks(text, TYPING_GROUP_SIZE):
                    cmd = f"cliclick w:{TYPING_DELAY_MS} t:{shlex.quote(chunk)}"
                    results.append(await self.shell(cmd, take_screenshot=False))
                screenshot_base64 = (await self.screenshot()).base64_image
                return ToolResult(
                    output="".join(result.output or "" for result in results),
                    error="".join(result.error or "" for result in results),
                    base64_image=screenshot_base64,
                )

        if action in (
            "left_click",
            "right_click",
            "double_click",
            "middle_click",
            "screenshot",
            "cursor_position",
        ):
            if text is not None:
                raise ToolError(f"text is not accepted for {action}")
            if coordinate is not None:
                raise ToolError(f"coordinate is not accepted for {action}")

            if action == "screenshot":
                return await self.screenshot()
            elif action == "cursor_position":
                result = await self.shell(
                    "cliclick p",
                    take_screenshot=False,
                )
                if result.output:
                    x, y = map(int, result.output.strip().split(","))
                    x, y = self.scale_coordinates(ScalingSource.COMPUTER, x, y)
                    return result.replace(output=f"X={x},Y={y}")
                return result
            else:
                click_cmd = {
                    "left_click": "c:.",
                    "right_click": "rc:.",
                    "middle_click": "mc:.",
                    "double_click": "dc:.",
                }[action]
                return await self.shell(f"cliclick {click_cmd}")

        raise ToolError(f"Invalid action: {action}")

    async def screenshot(self):
        """Take a screenshot of the current screen and return the base64 encoded image."""
        output_dir = Path(OUTPUT_DIR)
        output_dir.mkdir(parents=True, exist_ok=True)
        path = output_dir / f"screenshot_{uuid4().hex}.png"

        # Use macOS native screencapture
        screenshot_cmd = f"screencapture -x {path}"
        result = await self.shell(screenshot_cmd, take_screenshot=False)

        if self._scaling_enabled:
            x, y = SCALE_DESTINATION['width'], SCALE_DESTINATION['height']
            await self.shell(
                f"sips -z {y} {x} {path}",  # sips is macOS native image processor
                take_screenshot=False
            )

        if path.exists():
            return result.replace(
                base64_image=base64.b64encode(path.read_bytes()).decode()
            )
        raise ToolError(f"Failed to take screenshot: {result.error}")

    async def shell(self, command: str, take_screenshot=False) -> ToolResult:
        """Run a shell command and return the output, error, and optionally a screenshot."""
        _, stdout, stderr = await run(command)
        base64_image = None

        if take_screenshot:
            # delay to let things settle before taking a screenshot
            await asyncio.sleep(self._screenshot_delay)
            base64_image = (await self.screenshot()).base64_image

        return ToolResult(output=stdout, error=stderr, base64_image=base64_image)

    def scale_coordinates(self, source: ScalingSource, x: int, y: int) -> tuple[int, int]:
        """
        Scale coordinates between original resolution and target resolution (SCALE_DESTINATION).

        Args:
            source: ScalingSource.API for scaling up from SCALE_DESTINATION to original resolution
                   or ScalingSource.COMPUTER for scaling down from original to SCALE_DESTINATION
            x, y: Coordinates to scale

        Returns:
            Tuple of scaled (x, y) coordinates
        """
        if not self._scaling_enabled:
            return x, y

        # Calculate scaling factors
        x_scaling_factor = SCALE_DESTINATION['width'] / self.width
        y_scaling_factor = SCALE_DESTINATION['height'] / self.height

        if source == ScalingSource.API:
            # Scale up from SCALE_DESTINATION to original resolution
            if x > SCALE_DESTINATION['width'] or y > SCALE_DESTINATION['height']:
                raise ToolError(f"Coordinates {x}, {y} are out of bounds for {SCALE_DESTINATION['width']}x{SCALE_DESTINATION['height']}")
            return round(x / x_scaling_factor), round(y / y_scaling_factor)
        else:
            # Scale down from original resolution to SCALE_DESTINATION
            return round(x * x_scaling_factor), round(y * y_scaling_factor)

    def _determine_display_size(self) -> tuple[int, int]:
        """Determine the display size using env vars or system_profiler."""
        env_width = os.getenv("WIDTH")
        env_height = os.getenv("HEIGHT")
        if env_width and env_height:
            try:
                return int(env_width), int(env_height)
            except ValueError as exc:
                raise ToolError("WIDTH and HEIGHT environment variables must be integers") from exc

        profiler_size = self._primary_display_from_profiler()
        if profiler_size:
            return profiler_size

        return DEFAULT_WIDTH, DEFAULT_HEIGHT

    def _primary_display_from_profiler(self) -> tuple[int, int] | None:
        """Use system_profiler output to guess the active display size."""
        try:
            result = subprocess.run(
                ["/usr/sbin/system_profiler", "SPDisplaysDataType", "-json"],
                check=True,
                capture_output=True,
                text=True,
            )
        except (FileNotFoundError, subprocess.CalledProcessError):
            return None

        try:
            profiler = json.loads(result.stdout).get("SPDisplaysDataType", [])
        except json.JSONDecodeError:
            return None

        displays: list[dict[str, str]] = []
        for display in profiler:
            displays.extend(display.get("spdisplays_ndrvs", []))

        if not displays:
            return None

        def parse_pixels(entry: dict[str, str]) -> tuple[int, int] | None:
            pixel_string = entry.get("_spdisplays_pixels")
            if not pixel_string:
                return None
            parts = [part.strip() for part in pixel_string.lower().split("x")]
            if len(parts) != 2:
                return None
            try:
                return int(parts[0]), int(parts[1])
            except ValueError:
                return None

        preferred = next(
            (
                display
                for display in displays
                if display.get("spdisplays_main") == "spdisplays_yes"
            ),
            displays[0],
        )
        return parse_pixels(preferred)

    async def _press_key_sequence(self, sequence: str) -> ToolResult:
        """Dispatch modifier/key combos through AppleScript."""
        parts = [part.strip() for part in sequence.split("+") if part.strip()]
        if not parts:
            raise ToolError("No key provided")

        key = parts[-1]
        modifiers = parts[:-1]
        modifier_tokens = [self._map_modifier(modifier) for modifier in modifiers]
        key_command = self._map_key(key)

        if key_command["type"] == "keystroke":
            script = self._build_keystroke_script(
                key_command["value"], modifier_tokens
            )
        else:
            script = self._build_keycode_script(
                key_command["value"], modifier_tokens
            )

        command = f"osascript -e {shlex.quote(script)}"
        result = await self.shell(command, take_screenshot=False)
        output = result.output or f"Pressed key: {sequence}"
        return result.replace(output=output)

    def _map_modifier(self, modifier: str) -> str:
        symbol_lookup = {
            "⌘": "command down",
            "⌃": "control down",
            "⌥": "option down",
            "⇧": "shift down",
        }
        stripped = modifier.strip()
        if stripped in symbol_lookup:
            return symbol_lookup[stripped]

        lookup = {
            "cmd": "command down",
            "command": "command down",
            "control": "control down",
            "ctrl": "control down",
            "option": "option down",
            "opt": "option down",
            "alt": "option down",
            "shift": "shift down",
            "fn": "function down",
            "function": "function down",
        }
        normalized = re.sub(r"[^a-z]", "", stripped.lower())
        if normalized not in lookup:
            raise ToolError(f"Unsupported modifier: {modifier}")
        return lookup[normalized]

    def _map_key(self, key: str) -> dict[str, str | int]:
        normalized = re.sub(r"[^a-z0-9]", "", key.lower())
        key_code_map: dict[str, int] = {
            "return": 36,
            "enter": 76,
            "tab": 48,
            "escape": 53,
            "esc": 53,
            "delete": 51,
            "backspace": 51,
            "forwarddelete": 117,
            "home": 115,
            "end": 119,
            "pageup": 116,
            "pagedown": 121,
            "arrowup": 126,
            "arrowdown": 125,
            "arrowleft": 123,
            "arrowright": 124,
            "uparrow": 126,
            "downarrow": 125,
            "leftarrow": 123,
            "rightarrow": 124,
            "up": 126,
            "down": 125,
            "left": 123,
            "right": 124,
            "f1": 122,
            "f2": 120,
            "f3": 99,
            "f4": 118,
            "f5": 96,
            "f6": 97,
            "f7": 98,
            "f8": 100,
            "f9": 101,
            "f10": 109,
            "f11": 103,
            "f12": 111,
        }
        if normalized in key_code_map:
            return {"type": "keycode", "value": key_code_map[normalized]}

        if len(key) == 1:
            return {"type": "keystroke", "value": key.lower()}

        named_chars = {
            "space": " ",
            "period": ".",
            "dot": ".",
            "comma": ",",
            "semicolon": ";",
            "colon": ":",
            "slash": "/",
            "backslash": "\\",
            "quote": '"',
            "apostrophe": "'",
            "minus": "-",
            "underscore": "_",
            "plus": "+",
            "equals": "=",
            "equal": "=",
        }
        if normalized in named_chars:
            return {"type": "keystroke", "value": named_chars[normalized]}

        raise ToolError(f"Unsupported key: {key}")

    def _build_keystroke_script(self, key: str, modifiers: list[str]) -> str:
        clause = (
            f" using {{{', '.join(modifiers)}}}"
            if modifiers
            else ""
        )
        escaped = key.replace('"', '\\"')
        return f'tell application "System Events" to keystroke "{escaped}"{clause}'

    def _build_keycode_script(self, key_code: int, modifiers: list[str]) -> str:
        clause = (
            f" using {{{', '.join(modifiers)}}}"
            if modifiers
            else ""
        )
        return f"tell application \"System Events\" to key code {key_code}{clause}"
